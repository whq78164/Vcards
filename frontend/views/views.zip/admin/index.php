<?php
/* @var $this yii\web\View */
?>
<div class="col-md-8">
<h1>欢迎使用唯卡微名片营销平台</h1>

<p>

<?=$model?>
</p>

</div>