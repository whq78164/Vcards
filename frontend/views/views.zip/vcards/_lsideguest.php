<aside class="flexbox flex-vertical m-sidebox" id="j-m-aside" data-action="aside-menu2">
	
		
		
			<div class="flexbox flex-vertical m-side-nologin">
			<div class="m-flex">
				<a class="facebox" href="<?=\yii\helpers\Url::to(['vcards/login'], true)?>">
					<i class="iconfont face"></i>
					<div class="m-txt">点击登录</div>
				</a>
			</div>
			<div class="m-reg">
				<div class="m-txt">还没有名片账号?</div>
				<a class="m-btn" href="<?=\yii\helpers\Url::to(['site/signup'], true)?>">马上创建名片</a>
			</div>
		
	
</aside>

