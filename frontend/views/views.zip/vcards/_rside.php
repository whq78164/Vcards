
		
		
		<!-- 右侧栏 -->
		
<aside class="m-rside" id="j-m-rside">
	<ul class="m-rside-ul">
		
			
			
				<!--li id="j-i-add-store">
					<a href="javascript:void(0)" data-action="toastIcon">
						<i class="iconfont i-sc" id="i-sc"></i>
						<div class="m-tle">收藏名片</div>
					</a>
				</li>
	
				<li id="j-i-add-swap">
					<a href="javascript:void(0)">
					<i class="iconfont i-jh" id="i-jh"></i>
					<div class="m-tle">交换名片</div>
					</a>
				</li-->
			
				<li id="phoneShare">
			<a href="javascript:void(0)">
			<i class="iconfont i-share"></i>
			<div class="m-tle">分享名片</div>
			</a>
		</li>
<!--		
		<li>
			<a href="http://mp.soqi.cn/login/downLoadPhone.xhtml?id=12138C1D641F71957CB0BCD31B48A3E7">
			<i class="iconfont i-save"></i>
			<div class="m-tle">保存通讯录</div>
			</a>
		</li>

-->			
		

		
		
<!--		
		<li id="phoneDesktop">
			<a href="javascript:void(0)">
				<i class="iconfont i-phone"></i>
				<div class="m-tle">手机桌面</div>
			</a>
		</li>
-->		
		<!-- 
		<li>
			<a href="javascript:void(0)">
			<i class="iconfont i-qrcode"></i>
			<div class="m-tle">生成二维码</div>
			</a>
		</li> 
		-->
	</ul>
</aside> 
		<div class="m-side-overlay" data-action="aside-menu"></div>
<!-- 右侧栏结束 -->	

